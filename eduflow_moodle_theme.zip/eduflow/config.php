<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * EduFlow – Moodle child theme of Boost
 *
 * @package   theme_eduflow
 * @copyright 2024 EduFlow
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$THEME->name        = 'eduflow';
$THEME->fullname    = 'EduFlow LMS';
$THEME->parents     = ['boost'];   // Child of Boost (which itself extends core)
$THEME->sheets      = [];          // Compiled via SCSS below
$THEME->editor_sheets = [];
$THEME->usefallback = true;
$THEME->enable_dock = false;

// SCSS entry-points
$THEME->scss = function ($theme) {
    return theme_eduflow_get_main_scss_content($theme);
};

$THEME->prescsscallback  = 'theme_eduflow_get_pre_scss';
$THEME->extrascsscallback = 'theme_eduflow_get_extra_scss';

// Override layouts if needed (inherits Boost's by default)
$THEME->layouts = [];

// Favicon & logo handled via admin settings (see settings.php)
$THEME->hidefromselector = false;
