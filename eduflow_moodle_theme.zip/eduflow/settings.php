<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

/**
 * EduFlow theme settings.
 *
 * @package   theme_eduflow
 * @copyright 2024 EduFlow
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

if ($ADMIN->fulltree) {

    $settings = new theme_boost_admin_settingspage_tabs('themesettingeduflow',
        get_string('configtitle', 'theme_eduflow'));

    // ── Tab 1 – General ──────────────────────────────────────────────────────
    $page = new admin_settingpage('theme_eduflow_general',
        get_string('generalsettings', 'theme_boost'));

    // Brand colour
    $name        = 'theme_eduflow/brandcolor';
    $title       = get_string('brandcolor', 'theme_boost');
    $description = get_string('brandcolor_desc', 'theme_boost');
    $default     = '#00288e';
    $setting = new admin_setting_configcolourpicker($name, $title, $description, $default, null, false);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);

    // Site logo (uploaded file)
    $name        = 'theme_eduflow/logo';
    $title       = get_string('logo', 'theme_boost');
    $description = get_string('logo_desc', 'theme_boost');
    $setting = new admin_setting_configstoredfile($name, $title, $description, 'logo');
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);

    // Favicon
    $name        = 'theme_eduflow/favicon';
    $title       = get_string('favicon', 'theme_boost');
    $description = get_string('favicon_desc', 'theme_boost');
    $setting = new admin_setting_configstoredfile($name, $title, $description, 'favicon', 0,
        ['accepted_types' => ['.ico', '.png']]);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);

    $settings->add($page);

    // ── Tab 2 – Advanced (raw SCSS) ───────────────────────────────────────────
    $page = new admin_settingpage('theme_eduflow_advanced',
        get_string('advancedsettings', 'theme_boost'));

    // Raw SCSS override
    $name        = 'theme_eduflow/scsspre';
    $title       = get_string('rawscss', 'theme_boost');
    $description = get_string('rawscss_desc', 'theme_boost');
    $default     = '';
    $setting = new admin_setting_scsscode($name, $title, $description, $default, PARAM_RAW);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);

    $settings->add($page);
}
