# EduFlow – Moodle Child Theme (Boost)

A clean, modern Moodle 4.x child theme inspired by the **EduFlow LMS** design system.
Built on top of **Boost** (which itself extends Bootstrap 4).

---

## Design Highlights

| Token | Value |
|---|---|
| Primary colour | `#00288e` (deep navy) |
| Secondary colour | `#0058be` (vivid blue) |
| Background | `#f8f9ff` (off-white blue tint) |
| Font | [Lexend](https://fonts.google.com/specimen/Lexend) (300–800) |
| Border radius | 12px cards, 8px buttons, pill chips |
| Icon system | Google Material Symbols |

---

## File Structure

```
theme/eduflow/
├── config.php          ← Theme declaration (parent = boost)
├── version.php         ← Plugin version / Moodle requirement
├── lib.php             ← SCSS injection callbacks
├── settings.php        ← Admin settings page (colour picker, logo, raw SCSS)
├── scss/
│   └── eduflow.scss    ← All custom styles
├── lang/
│   ├── en/theme_eduflow.php
│   └── fr/theme_eduflow.php
├── pix/                ← Put screenshot.png here (recommended 1280×960)
└── README.md
```

---

## Installation

1. **Copy** the `eduflow/` folder into `<moodleroot>/theme/`.
2. Log in as **admin** → *Site administration → Appearance → Themes → Theme selector*.
3. Click **Select theme** next to **EduFlow LMS**.
4. Visit *Site administration → Appearance → Themes → EduFlow LMS* to:
   - Change the **brand colour**
   - Upload a **logo** and **favicon**
   - Add **custom SCSS**

> **Moodle requirement:** ≥ 4.0 (2022041900)

---

## Customisation

### Via the admin UI
Navigate to **Site administration → Appearance → Themes → EduFlow LMS → Advanced** and paste any extra SCSS into the *Raw SCSS* field.

### Via the SCSS file
Edit `scss/eduflow.scss` and purge the theme cache:
```
Site administration → Development → Purge all caches
```

### CSS custom properties
All colours are exposed as CSS variables in `:root` (see `eduflow.scss`), so you can override them with a few lines of raw CSS without touching SCSS at all:

```css
:root {
  --ef-primary: #006644;   /* swap navy for green */
}
```

---

## Calendar Event Colour Coding

| Class applied by Moodle | EduFlow colour |
|---|---|
| `.calendar_event_course` | Blue (secondary) |
| `.calendar_event_global` | Brown (tertiary) |
| `.calendar_event_user`   | Red (error)      |
| `.calendar_event_group`  | Slate            |

---

## Adding a Screenshot

Place a `1280 × 960 px` PNG named **`screenshot.png`** inside `pix/` — Moodle will display it in the theme selector.

---

## Licence

GNU General Public License v3 or later – see <http://www.gnu.org/licenses/>.
