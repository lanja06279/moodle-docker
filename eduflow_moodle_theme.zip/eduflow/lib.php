<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

/**
 * EduFlow theme lib – SCSS injection callbacks.
 *
 * @package   theme_eduflow
 * @copyright 2024 EduFlow
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

/**
 * Returns the SCSS variables that are injected *before* Boost's own SCSS.
 * Override Bootstrap / Boost tokens here so the entire chain picks them up.
 */
function theme_eduflow_get_pre_scss($theme) {
    // ── Brand colours (matching EduFlow palette) ────────────────────────────
    $scss = '
// ── EduFlow brand tokens ──────────────────────────────────────────────────
$primary:               #00288e;
$secondary:             #0058be;
$body-bg:               #f8f9ff;
$body-color:            #0b1c30;
$link-color:            #3755c3;
$border-radius:         0.5rem;
$border-radius-lg:      0.75rem;
$border-radius-pill:    9999px;

// Typography
$font-family-sans-serif: "Lexend", system-ui, sans-serif;
$headings-font-weight:   700;
$headings-color:         #00288e;

// Navbar
$navbar-light-color:            #444653;
$navbar-light-active-color:     #00288e;
$navbar-padding-y:              1rem;

// Sidebar / drawer
$drawer-width:          280px;

// Cards
$card-border-color:     #e2e8f0;
$card-border-radius:    0.75rem;
$card-cap-bg:           #f8faff;

// Buttons
$btn-border-radius:     0.5rem;
$btn-font-weight:       600;
';

    // Allow admin to override the brand colour via settings
    if (!empty($theme->settings->brandcolor)) {
        $scss .= '$primary: ' . $theme->settings->brandcolor . ';' . "\n";
    }

    return $scss;
}

/**
 * Returns the main SCSS file content (compiled after pre-scss + Boost core).
 */
function theme_eduflow_get_main_scss_content($theme) {
    global $CFG;

    $scss  = '';

    // Pull in Boost's compiled base first
    $scss .= file_get_contents($CFG->dirroot . '/theme/boost/scss/preset/default.scss');

    // Then our custom overrides
    $scss .= file_get_contents($CFG->dirroot . '/theme/eduflow/scss/eduflow.scss');

    return $scss;
}

/**
 * Extra SCSS appended last (highest specificity wins).
 */
function theme_eduflow_get_extra_scss($theme) {
    $extra = '';

    // Custom CSS typed by the admin in the settings form
    if (!empty($theme->settings->scsspre)) {
        $extra .= $theme->settings->scsspre;
    }

    return $extra;
}
