<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

/**
 * Chaînes de langue françaises pour theme_eduflow.
 *
 * @package   theme_eduflow
 * @copyright 2024 EduFlow
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['pluginname']  = 'EduFlow LMS';
$string['configtitle'] = 'Paramètres du thème EduFlow';

$string['choosereadme'] = '
<div class="clearfix">
<h2>Thème EduFlow LMS</h2>
<p>Un thème enfant moderne de Boost pour Moodle 4.x.<br>
Inspiré des LMS contemporains : palette bleu marine, typographie Lexend,
mise en page en cartes et calendrier soigné.</p>
<h3>Fonctionnalités</h3>
<ul>
  <li>Palette bleue marine personnalisable</li>
  <li>Police Lexend (graisse variable)</li>
  <li>Étiquettes d'événements de calendrier revisitées</li>
  <li>Navigation latérale améliorée</li>
  <li>Composants Card et FAB</li>
  <li>Sélecteur de couleur et champ SCSS personnalisé</li>
</ul>
</div>';
