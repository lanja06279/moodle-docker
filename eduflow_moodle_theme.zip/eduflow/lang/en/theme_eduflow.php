<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

/**
 * English language strings for theme_eduflow.
 *
 * @package   theme_eduflow
 * @copyright 2024 EduFlow
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['pluginname']  = 'EduFlow LMS';
$string['configtitle'] = 'EduFlow Theme Settings';

$string['choosereadme'] = '
<div class="clearfix">
<h2>EduFlow LMS Theme</h2>
<p>A clean, modern child theme of Boost for Moodle 4.x.<br>
Inspired by contemporary LMS design systems featuring a blue-navy palette,
Lexend typography, card-based layouts, and a polished calendar interface.</p>
<h3>Features</h3>
<ul>
  <li>Blue-navy brand palette (configurable)</li>
  <li>Lexend variable-weight font</li>
  <li>Redesigned calendar event pills</li>
  <li>Enhanced sidebar navigation</li>
  <li>Card and FAB components</li>
  <li>Admin colour-picker &amp; custom SCSS field</li>
</ul>
</div>';
