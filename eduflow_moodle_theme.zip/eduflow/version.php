<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

/**
 * EduFlow theme version file.
 *
 * @package   theme_eduflow
 * @copyright 2024 EduFlow
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$plugin->version   = 2024090100;   // YYYYMMDDXX
$plugin->requires  = 2022041900;   // Minimum Moodle 4.0
$plugin->component = 'theme_eduflow';
$plugin->maturity  = MATURITY_STABLE;
$plugin->release   = '1.0.0';
