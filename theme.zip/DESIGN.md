---
name: Course Editor System
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#414751'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#717783'
  outline-variant: '#c1c7d3'
  surface-tint: '#0060ac'
  primary: '#005da7'
  on-primary: '#ffffff'
  primary-container: '#2976c7'
  on-primary-container: '#fdfcff'
  inverse-primary: '#a4c9ff'
  secondary: '#585f66'
  on-secondary: '#ffffff'
  secondary-container: '#dce3eb'
  on-secondary-container: '#5e656c'
  tertiary: '#006949'
  on-tertiary: '#ffffff'
  tertiary-container: '#00855d'
  on-tertiary-container: '#f5fff7'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d4e3ff'
  primary-fixed-dim: '#a4c9ff'
  on-primary-fixed: '#001c39'
  on-primary-fixed-variant: '#004883'
  secondary-fixed: '#dce3eb'
  secondary-fixed-dim: '#c0c7cf'
  on-secondary-fixed: '#151c22'
  on-secondary-fixed-variant: '#40484e'
  tertiary-fixed: '#68fcbf'
  tertiary-fixed-dim: '#45dfa4'
  on-tertiary-fixed: '#002114'
  on-tertiary-fixed-variant: '#005137'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  headline-lg:
    fontFamily: Lexend
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-md:
    fontFamily: Lexend
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 28px
  body-lg:
    fontFamily: Lexend
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Lexend
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-caps:
    fontFamily: Lexend
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  button:
    fontFamily: Lexend
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 20px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  margin-edge: 20px
  gutter: 12px
  touch-target-min: 48px
  stack-sm: 16px
  stack-md: 24px
  stack-lg: 40px
---

## Brand & Style

This design system is built on the philosophy of **Cognitive Calm**. It transforms the traditionally dense and overwhelming experience of course editing into a series of focused, manageable micro-interactions. The target audience includes educators and instructional designers who require a tool that feels more like a modern note-taking app than a database management system.

The aesthetic leans heavily into **Minimalism** with a **Modern Corporate** influence. It prioritizes clarity over decoration, using ample negative space to create a visual "breathing room" that reduces the anxiety of content creation. The interface is intentionally modest, ensuring that the educator's content—rather than the tool's chrome—remains the focal point.

## Colors

The palette is anchored in **soft blues and airy grays** to foster a sense of trust and stability. 

- **Primary Blue (#4A90E2):** Used sparingly for primary actions and active states to guide the eye without shouting.
- **Secondary Sky (#F0F7FF):** Applied to large background surfaces and container fills to create a soft, non-fatiguing canvas.
- **Success Mint (#34D399):** Reserved for "Published" statuses and completed module indicators.
- **Slate Neutrals:** A range of cool-toned grays used for typography and iconography, ensuring high legibility while avoiding the harshness of pure black.

The default color mode is **Light**, optimized for daytime productivity and clarity.

## Typography

The design system utilizes **Lexend** across all levels. Originally designed to reduce visual stress and improve reading speed, Lexend's expanded character spacing and geometric clarity make it the perfect choice for an educational tool.

The type scale is intentionally limited to prevent hierarchy confusion. Headlines use a medium-to-semibold weight to provide structure without feeling heavy. Body text maintains a generous line height (1.5x) to ensure long-form course descriptions remain readable on mobile screens. Small labels use all-caps with light tracking to distinguish metadata from content.

## Layout & Spacing

This design system employs a **Fluid Layout** optimized for mobile-first interaction. It utilizes a base 8px rhythmic grid to ensure vertical consistency. 

Key layout principles:
- **Generous Margins:** A 20px side margin ensures that content does not feel cramped against the bezel and provides a safe zone for thumb-scrolling.
- **Touch-First Sizing:** All interactive elements (buttons, toggles, inputs) must adhere to a minimum 48px height.
- **Vertical Stack:** Content follows a single-column flow. Modules and lessons are stacked with 16px or 24px gaps to visually separate distinct "learning chunks."
- **White Space as a Divider:** Rather than heavy lines, use 40px gaps to separate major sections of the course editor.

## Elevation & Depth

To maintain a clean aesthetic, this design system avoids heavy, dark shadows. Depth is communicated through **Tonal Layers** and **Low-Contrast Outlines**.

- **Background:** The base layer uses a very light gray or off-white.
- **Surface (Cards):** Primary containers (like a course module) are pure white with a subtle 1px border (#E2E8F0).
- **Active Elevation:** When an item is being "dragged" to reorder, it gains a soft, diffused ambient shadow (10% opacity, 12px blur) to indicate it has been lifted from the stack.
- **Overlays:** Modals and bottom sheets use a subtle backdrop blur (12px) to keep the user grounded in their current context while focusing on the task at hand.

## Shapes

The shape language is **Rounded**, using a 0.5rem (8px) base radius. This softens the interface and makes the tool feel approachable rather than institutional. 

- **Cards & Sections:** Use the `rounded-lg` (16px) treatment to create distinct, friendly containers for course content.
- **Input Fields:** Use the standard 8px radius for a familiar, modern feel.
- **Interactive Chips:** For tags (e.g., "Draft", "Quiz", "Video"), use the `rounded-xl` (24px) or pill-shape to distinguish them from actionable buttons.

## Components

### Buttons & Touch Targets
Primary buttons are high-height (52px) with centered text and 16px horizontal padding. Ghost buttons (border-only) should be used for secondary actions like "Add Resource" to keep the visual weight low.

### Course Module Cards
Each module is a white card with a 1px border. They include a drag-handle icon on the left, a bold title, and a sub-label indicating the number of items within.

### Interactive Lists
Lesson items within a module use a "zebra-striping" alternative or subtle dividers. Each row must have a minimum 56px height to prevent accidental taps.

### Input Fields
Forms use top-aligned labels in `label-caps`. The input area itself is a soft gray fill with a subtle 1px border that turns Blue (#4A90E2) on focus.

### Progress Indicators
Simplified horizontal bars with rounded ends. Use the Secondary Sky color for the track and Primary Blue for the progress fill.

### Draggable Reordering
A dedicated handle icon (six dots) must be present on any reorderable element, providing a clear visual affordance for the "move" action.